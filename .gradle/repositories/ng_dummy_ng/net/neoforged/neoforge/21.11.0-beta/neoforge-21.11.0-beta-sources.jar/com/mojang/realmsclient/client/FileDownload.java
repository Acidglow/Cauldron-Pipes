package com.mojang.realmsclient.client;

import com.google.common.hash.Hashing;
import com.google.common.io.Files;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.dto.WorldDownload;
import com.mojang.realmsclient.exception.RealmsDefaultUncaughtExceptionHandler;
import com.mojang.realmsclient.gui.screens.RealmsDownloadLatestWorldScreen;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.Builder;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Locale;
import java.util.OptionalLong;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.CheckReturnValue;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NbtException;
import net.minecraft.nbt.ReportedNbtException;
import net.minecraft.util.Util;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.validation.ContentValidationException;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.CountingOutputStream;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class FileDownload {
    private static final Logger LOGGER = LogUtils.getLogger();
    private volatile boolean cancelled;
    private volatile boolean finished;
    private volatile boolean error;
    private volatile boolean extracting;
    private volatile @Nullable File tempFile;
    private volatile File resourcePackPath;
    private volatile @Nullable CompletableFuture<?> pendingRequest;
    private @Nullable Thread currentThread;
    private static final String[] INVALID_FILE_NAMES = new String[]{
        "CON",
        "COM",
        "PRN",
        "AUX",
        "CLOCK$",
        "NUL",
        "COM1",
        "COM2",
        "COM3",
        "COM4",
        "COM5",
        "COM6",
        "COM7",
        "COM8",
        "COM9",
        "LPT1",
        "LPT2",
        "LPT3",
        "LPT4",
        "LPT5",
        "LPT6",
        "LPT7",
        "LPT8",
        "LPT9"
    };

    private <T> @Nullable T joinCancellableRequest(CompletableFuture<T> request) throws Throwable {
        this.pendingRequest = request;
        if (this.cancelled) {
            request.cancel(true);
            return null;
        } else {
            try {
                try {
                    return request.join();
                } catch (CompletionException completionexception) {
                    throw completionexception.getCause();
                }
            } catch (CancellationException cancellationexception) {
                return null;
            }
        }
    }

    private static HttpClient createClient() {
        return HttpClient.newBuilder().executor(Util.nonCriticalIoPool()).connectTimeout(Duration.ofMinutes(2L)).build();
    }

    private static Builder createRequest(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofMinutes(2L));
    }

    @CheckReturnValue
    public static OptionalLong contentLength(String url) {
        try {
            OptionalLong optionallong;
            try (HttpClient httpclient = createClient()) {
                HttpResponse<Void> httpresponse = httpclient.send(createRequest(url).HEAD().build(), BodyHandlers.discarding());
                optionallong = httpresponse.headers().firstValueAsLong("Content-Length");
            }

            return optionallong;
        } catch (Exception exception) {
            LOGGER.error("Unable to get content length for download");
            return OptionalLong.empty();
        }
    }

    public void download(WorldDownload download, String worldName, RealmsDownloadLatestWorldScreen.DownloadStatus status, LevelStorageSource source) {
        if (this.currentThread == null) {
            this.currentThread = new Thread(() -> {
                try (HttpClient httpclient = createClient()) {
                    try {
                        this.tempFile = File.createTempFile("backup", ".tar.gz");
                        this.download(status, httpclient, download.downloadLink(), this.tempFile);
                        this.finishWorldDownload(worldName.trim(), this.tempFile, source, status);
                    } catch (Exception exception1) {
                        LOGGER.error("Caught exception while downloading world", (Throwable)exception1);
                        this.error = true;
                    } finally {
                        this.pendingRequest = null;
                        if (this.tempFile != null) {
                            this.tempFile.delete();
                        }

                        this.tempFile = null;
                    }

                    if (this.error) {
                        return;
                    }

                    String s = download.resourcePackUrl();
                    if (!s.isEmpty() && !download.resourcePackHash().isEmpty()) {
                        try {
                            this.tempFile = File.createTempFile("resources", ".tar.gz");
                            this.download(status, httpclient, s, this.tempFile);
                            this.finishResourcePackDownload(status, this.tempFile, download);
                        } catch (Exception exception) {
                            LOGGER.error("Caught exception while downloading resource pack", (Throwable)exception);
                            this.error = true;
                        } finally {
                            this.pendingRequest = null;
                            if (this.tempFile != null) {
                                this.tempFile.delete();
                            }

                            this.tempFile = null;
                        }
                    }

                    this.finished = true;
                }
            });
            this.currentThread.setUncaughtExceptionHandler(new RealmsDefaultUncaughtExceptionHandler(LOGGER));
            this.currentThread.start();
        }
    }

    private void download(RealmsDownloadLatestWorldScreen.DownloadStatus status, HttpClient client, String url, File tempFile) throws IOException {
        HttpRequest httprequest = createRequest(url).GET().build();

        HttpResponse<InputStream> httpresponse;
        try {
            httpresponse = this.joinCancellableRequest(client.sendAsync(httprequest, BodyHandlers.ofInputStream()));
        } catch (Error errorx) {
            throw errorx;
        } catch (Throwable throwable) {
            LOGGER.error("Failed to download {}", url, throwable);
            this.error = true;
            return;
        }

        if (httpresponse != null && !this.cancelled) {
            if (httpresponse.statusCode() != 200) {
                this.error = true;
            } else {
                status.totalBytes = httpresponse.headers().firstValueAsLong("Content-Length").orElse(0L);

                try (
                    InputStream inputstream = httpresponse.body();
                    OutputStream outputstream = new FileOutputStream(tempFile);
                ) {
                    inputstream.transferTo(new FileDownload.DownloadCountingOutputStream(outputstream, status));
                }
            }
        }
    }

    public void cancel() {
        if (this.tempFile != null) {
            this.tempFile.delete();
            this.tempFile = null;
        }

        this.cancelled = true;
        CompletableFuture<?> completablefuture = this.pendingRequest;
        if (completablefuture != null) {
            completablefuture.cancel(true);
        }
    }

    public boolean isFinished() {
        return this.finished;
    }

    public boolean isError() {
        return this.error;
    }

    public boolean isExtracting() {
        return this.extracting;
    }

    /**
     * Modifies a folder name to make sure it is valid to store on disk.
     * @return the modified folder name
     *
     * @param folderName The folder name to modify
     */
    public static String findAvailableFolderName(String folderName) {
        folderName = folderName.replaceAll("[\\./\"]", "_");

        for (String s : INVALID_FILE_NAMES) {
            if (folderName.equalsIgnoreCase(s)) {
                folderName = "_" + folderName + "_";
            }
        }

        return folderName;
    }

    private void untarGzipArchive(String worldName, @Nullable File tempFile, LevelStorageSource levelStorageSource) throws IOException {
        Pattern pattern = Pattern.compile(".*-([0-9]+)$");
        int i = 1;

        for (char c0 : SharedConstants.ILLEGAL_FILE_CHARACTERS) {
            worldName = worldName.replace(c0, '_');
        }

        if (StringUtils.isEmpty(worldName)) {
            worldName = "Realm";
        }

        worldName = findAvailableFolderName(worldName);

        try {
            for (LevelStorageSource.LevelDirectory levelstoragesource$leveldirectory : levelStorageSource.findLevelCandidates()) {
                String s1 = levelstoragesource$leveldirectory.directoryName();
                if (s1.toLowerCase(Locale.ROOT).startsWith(worldName.toLowerCase(Locale.ROOT))) {
                    Matcher matcher = pattern.matcher(s1);
                    if (matcher.matches()) {
                        int j = Integer.parseInt(matcher.group(1));
                        if (j > i) {
                            i = j;
                        }
                    } else {
                        i++;
                    }
                }
            }
        } catch (Exception exception1) {
            LOGGER.error("Error getting level list", (Throwable)exception1);
            this.error = true;
            return;
        }

        String s;
        if (levelStorageSource.isNewLevelIdAcceptable(worldName) && i <= 1) {
            s = worldName;
        } else {
            s = worldName + (i == 1 ? "" : "-" + i);
            if (!levelStorageSource.isNewLevelIdAcceptable(s)) {
                boolean flag = false;

                while (!flag) {
                    i++;
                    s = worldName + (i == 1 ? "" : "-" + i);
                    if (levelStorageSource.isNewLevelIdAcceptable(s)) {
                        flag = true;
                    }
                }
            }
        }

        TarArchiveInputStream tararchiveinputstream = null;
        File file1 = new File(Minecraft.getInstance().gameDirectory.getAbsolutePath(), "saves");

        try {
            file1.mkdir();
            tararchiveinputstream = new TarArchiveInputStream(new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(tempFile))));

            for (TarArchiveEntry tararchiveentry = tararchiveinputstream.getNextTarEntry();
                tararchiveentry != null;
                tararchiveentry = tararchiveinputstream.getNextTarEntry()
            ) {
                File file2 = new File(file1, tararchiveentry.getName().replace("world", s));
                if (tararchiveentry.isDirectory()) {
                    file2.mkdirs();
                } else {
                    file2.createNewFile();

                    try (FileOutputStream fileoutputstream = new FileOutputStream(file2)) {
                        IOUtils.copy(tararchiveinputstream, fileoutputstream);
                    }
                }
            }
        } catch (Exception exception) {
            LOGGER.error("Error extracting world", (Throwable)exception);
            this.error = true;
        } finally {
            if (tararchiveinputstream != null) {
                tararchiveinputstream.close();
            }

            if (tempFile != null) {
                tempFile.delete();
            }

            try (LevelStorageSource.LevelStorageAccess levelstoragesource$levelstorageaccess = levelStorageSource.validateAndCreateAccess(s)) {
                levelstoragesource$levelstorageaccess.renameAndDropPlayer(s);
            } catch (NbtException | ReportedNbtException | IOException ioexception) {
                LOGGER.error("Failed to modify unpacked realms level {}", s, ioexception);
            } catch (ContentValidationException contentvalidationexception) {
                LOGGER.warn("Failed to download file", (Throwable)contentvalidationexception);
            }

            this.resourcePackPath = new File(file1, s + File.separator + "resources.zip");
        }
    }

    private void finishWorldDownload(String worldName, File tempFile, LevelStorageSource source, RealmsDownloadLatestWorldScreen.DownloadStatus status) {
        if (status.bytesWritten >= status.totalBytes && !this.cancelled && !this.error) {
            try {
                this.extracting = true;
                this.untarGzipArchive(worldName, tempFile, source);
            } catch (IOException ioexception) {
                LOGGER.error("Error extracting archive", (Throwable)ioexception);
                this.error = true;
            }
        }
    }

    private void finishResourcePackDownload(RealmsDownloadLatestWorldScreen.DownloadStatus status, File tempFile, WorldDownload worldDownload) {
        if (status.bytesWritten >= status.totalBytes && !this.cancelled) {
            try {
                String s = Hashing.sha1().hashBytes(Files.toByteArray(tempFile)).toString();
                if (s.equals(worldDownload.resourcePackHash())) {
                    FileUtils.copyFile(tempFile, this.resourcePackPath);
                    this.finished = true;
                } else {
                    LOGGER.error("Resourcepack had wrong hash (expected {}, found {}). Deleting it.", worldDownload.resourcePackHash(), s);
                    FileUtils.deleteQuietly(tempFile);
                    this.error = true;
                }
            } catch (IOException ioexception) {
                LOGGER.error("Error copying resourcepack file: {}", ioexception.getMessage());
                this.error = true;
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class DownloadCountingOutputStream extends CountingOutputStream {
        private final RealmsDownloadLatestWorldScreen.DownloadStatus downloadStatus;

        public DownloadCountingOutputStream(OutputStream parent, RealmsDownloadLatestWorldScreen.DownloadStatus downloadStatus) {
            super(parent);
            this.downloadStatus = downloadStatus;
        }

        @Override
        protected void afterWrite(int bytesWritten) throws IOException {
            super.afterWrite(bytesWritten);
            this.downloadStatus.bytesWritten = this.getByteCount();
        }
    }
}
